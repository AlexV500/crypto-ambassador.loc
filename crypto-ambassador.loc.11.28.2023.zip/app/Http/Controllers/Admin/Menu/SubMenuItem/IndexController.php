<?php

namespace App\Http\Controllers\Admin\Menu\SubMenuItem;

use App\Models\Menu\MenuItem;
use App\Models\Menu\MenuWidget;

class IndexController extends BaseSubController{

    public function __invoke(MenuWidget $menuWidget, MenuItem $parentItem){

      //  dd($menuWidget);

        $menuItems = $parentItem->getMenuItemsChild();

        $menuTypes = $this->getSubMenuItemTypes();
        $locales = $this->getAllLocalizations();
        $getCurrentLocale = $this->getCurrentLocale();
        $getLocaleName = $this->getLocaleName();

        return view('admin.menu.submenuitem.index', compact(
            'menuWidget',
            'parentItem',
            'menuItems',
            'menuTypes',
            'locales',
            'getCurrentLocale',
            'getLocaleName'));
    }
}

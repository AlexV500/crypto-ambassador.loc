<?php

namespace App\Http\Controllers\Admin\Menu\SubMenuItem;

use App\Helpers\Menu\MenuHelper;
use App\Models\Menu\MenuItem;
use App\Models\Menu\MenuWidget;

class EditController extends BaseSubController{

    public function __invoke(MenuWidget $menuWidget, MenuItem $menuItem){

     //   dd(MenuHelper::treeMenuItems());

        $treeMenuItems = MenuHelper::treeMenuItems();
        $getCurrentLocale = $this->getCurrentLocale();
        $getLocaleName = $this->getLocaleName();
        $locales = $this->getAllLocalizations();
        $menuTypes = $this->getSubMenuItemTypes();
        $parentItem = $menuItem->getParentItem();

        return view('admin.menu.submenuitem.edit', compact(
            'menuWidget',
            'parentItem',
            'treeMenuItems',
            'menuItem',
            'menuTypes',
            'locales',
            'getCurrentLocale',
            'getLocaleName'));
    }
}

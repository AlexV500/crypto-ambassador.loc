<?php

namespace App\Services\Admin;

use App\Models\MenuItem;
use App\Models\MenuWidget;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
class MenuService{

    public function positionUp($id, $widgetMenuId, $type, $parentId, $column) : bool
    {
        $currentRow = null;
        $nextRowId = null;
        $count = MenuItem::getMenuCount($widgetMenuId, $type, $parentId, $column);
        $allRows = MenuItem::getMenuAllRows($widgetMenuId, $type, $parentId, $column);
        $nextRowById = MenuItem::getNextRowById($id, $widgetMenuId, $type, $parentId, $column);

        if (($count > 1) && ($id > 0)) {
            foreach ($allRows as $row) {
                if ($row->id == $id) {
                    if ($nextRowById !== null) {
                        $currentRow = $nextRowById;
                        $nextRowId = $row->id;
                    } else return false;
                }
            }
            return $this->setPosition($id, $currentRow, $nextRowId);
        } else return false;
    }

    public function positionDown($id, $widgetMenuId, $type, $parentId, $column) : bool
    {
        $currentRow = null;
        $prevRowId = null;
        $count = MenuItem::getMenuCount($widgetMenuId, $type, $parentId, $column);
        $allRows = MenuItem::getMenuAllRows($widgetMenuId, $type, $parentId, $column);
        $prevRowById = MenuItem::getPrevRowById($id, $widgetMenuId, $type, $parentId, $column);

        if (($count > 1) && ($id > 0)) {
            foreach ($allRows as $row) {
                if ($row->id == $id) {
                    if ($prevRowById !== null) {
                        $currentRow = $prevRowById;
                        $prevRowId = $row;
                    } else return false;
                }
            }
            return $this->setPosition($id, $currentRow, $prevRowId);
        } else return false;
    }

    protected function setPosition($currentRow, $nextOrPrevRowId) : bool
    {
        $prewOrNextData = MenuItem::query()->where('id', '=>',  $nextOrPrevRowId)->first();

        try {
            DB::beginTransaction();

            // dd($data);
            DB::table('menus')
                ->where('id', $currentRow->id)
                ->update(['position' => $prewOrNextData->position]);

            DB::table('menus')
                ->where('id', $nextOrPrevRowId->id)
                ->update(['position' => $currentRow->position]);

            DB::commit();

        } catch (\Exception $exception) {
            DB::rollBack();
            abort(500);
        }
        return true;
    }

}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class MenuItem extends Model {

    use HasFactory, SoftDeletes;

    protected $table = 'menu_items';
    protected $guarded = false;

    public function getChilds($id)
    {
        return $this->where("parent_id", $id)->get();
    }
    public function getAll($id)
    {
        return $this->where("widget_menu_id", $id)->orderBy("position", "asc")->get();
    }

    public static function getNextSortRoot($menuId, $type)
    {
        return self::where('widget_menu_id', $menuId)->where('type', $type)->max('position') + 1;
    }

    public function parentMenu()
    {
        return $this->belongsTo('App\Models\MenuWidget', 'widget_menu_id');
    }

    public function child()
    {
        return $this->hasMany('App\Models\MenuItem', 'parent_id')->orderBy('position', 'ASC');
    }

    public static function getMenuCount($widgetMenuId, $type, $parentId, $column) : int
    {
        return self::getMenuQuery($widgetMenuId, $type, $parentId, $column)->get()->count();
    }
    public static function getPrevRowById($id, $widgetMenuId, $type, $parentId, $column)
    {
        if($type == 'multicolumn'){
            $query = self::where('id', '<', $id)->where('widget_menu_id', '=', $widgetMenuId)->where('column', '=', $column);
        }
        else {
            $query = self::where('id', '<', $id)->where('widget_menu_id', '=', $widgetMenuId)->where('parent_id', '=', $parentId);
        }
        return $query->max('id');
    }

    public static function getNextRowById($id, $widgetMenuId, $type, $parentId, $column)
    {
        if($type == 'multicolumn'){
            $query = self::where('id', '>', $id)->where('widget_menu_id', '=', $widgetMenuId)->where('column', '=', $column);
        }
        else {
            $query = self::where('id', '>', $id)->where('widget_menu_id', '=', $widgetMenuId)->where('parent_id', '=', $parentId);
        }
        return $query->min('id');
    }

    public static function getMenuAllRows($widgetMenuId, $type, $parentId, $column)
    {
        return self::getMenuQuery($widgetMenuId, $type, $parentId, $column)->get();
    }
    public static function getMaxPosition($widgetMenuId, $type, $parentId, $column) : int
    {
        return self::getMenuQuery($widgetMenuId, $type, $parentId, $column)->max('position');
    }
    public static function getMenuQuery($widgetMenuId, $type, $parentId, $column){

        if($type == 'multicolumn'){
            $query = self::where('widget_menu_id', '=', $widgetMenuId)->where('column', '=', $column);
        }
        else {
            $query = self::where('widget_menu_id', '=', $widgetMenuId)->where('parent_id', '=', $parentId);
        }
        return $query;
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class MenuWidget extends Model{

    use HasFactory, SoftDeletes;

    protected $table = 'widget_menu';
    protected $guarded = false;

    public static function bySystemName($systemName){

        return self::where('system_name', '=', $systemName)->first();
    }

    public function items(){

        return $this->hasMany('App\Models\MenuItem', 'widget_menu_id')->with('child')->where('parent', 0)->orderBy('position', 'ASC');
    }
}

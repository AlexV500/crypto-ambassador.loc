<?php

namespace App\Http\Controllers\Admin\Menu;

use App\Http\Controllers\SiteController;
use App\Models\MenuWidget;

class IndexController extends SiteController{

    public function __invoke(){

        $menuWigets = MenuWidget::where('lang', '=', $this->getCurrentLocale());
    }
}

<?php

namespace App\Http\Controllers\Admin\Menu;

use App\Services\Admin\MenuService;

class PositionController extends BaseController{

    public int $id;
    public int $widgetMenuId;
    public string $type;
    public string $parentId;
    public int $column;

    public function init(){
        $this->id = request()->query('id');
        $this->widgetMenuId = request()->query('widgetMenuId');
        $this->type = request()->query('type');
        $this->parentId = request()->query('parentId');
        $this->column = request()->query('column');
    }
    public function PositionUp(){
        $this->service->positionUp($this->id, $this->widgetMenuId, $this->type, $this->parentId, $this->column);
        return redirect()->route('admin.menu.index');
    }

    public function PositionDown(){
        $this->service->positionDown($this->id, $this->widgetMenuId, $this->type, $this->parentId, $this->column);
        return redirect()->route('admin.menu.index');
    }
}

<?php return array (
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/socialite' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Socialite\\SocialiteServiceProvider',
    ),
    'aliases' => 
    array (
      'Socialite' => 'Laravel\\Socialite\\Facades\\Socialite',
    ),
  ),
  'laravel/telescope' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Telescope\\TelescopeServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravel/ui' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Ui\\UiServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'spatie/laravel-ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Spatie\\LaravelIgnition\\Facades\\Flare',
    ),
  ),
  'spatie/laravel-menu' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Menu\\Laravel\\MenuServiceProvider',
    ),
    'aliases' => 
    array (
      'Menu' => 'Spatie\\Menu\\Laravel\\Facades\\Menu',
    ),
  ),
  'spatie/laravel-navigation' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Navigation\\NavigationServiceProvider',
    ),
    'aliases' => 
    array (
      'Navigation' => 'Spatie\\Navigation\\Facades\\Navigation',
    ),
  ),
  'webwizo/laravel-shortcodes' => 
  array (
    'providers' => 
    array (
      0 => 'Webwizo\\Shortcodes\\ShortcodesServiceProvider',
    ),
    'aliases' => 
    array (
      'Shortcode' => 'Webwizo\\Shortcodes\\Facades\\Shortcode',
    ),
  ),
);
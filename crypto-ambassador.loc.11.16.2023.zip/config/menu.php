<?php

return [

    'base' => [
        'type' => 'dropdown'
    ],
];

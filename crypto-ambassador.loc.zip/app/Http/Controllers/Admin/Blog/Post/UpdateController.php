<?php

namespace App\Http\Controllers\Admin\Blog\Post;

use App\Http\Requests\Admin\Blog\Post\UpdateRequest;
use App\Models\Blog\Post;

class UpdateController extends BaseController{

    public function __invoke(UpdateRequest $request, Post $post){

        $data = $request->validated();
        $post = $this->service->update($data, $post);
        $getLocale = $this->getLocale();
        $getLocaleName = $this->getLocaleName();
        $locales = $this->getAllLocalizations();

        return view('admin.blog.post.show', compact(
            'post',
            'getLocale',
            'getLocaleName',
            'locales'));
    }
}

<?php

namespace App\Http\Controllers\Admin\Main;

use App\Http\Controllers\Controller;
use App\Http\Controllers\SiteController;
use App\Models\Blog\Category;
use App\Models\Blog\Post;
use App\Models\Blog\Tag;
use App\Models\User;

class IndexController extends SiteController{

    public function __invoke(){

        $data = [];
        $data['usersCount'] = User::all()->count();
        $data['postsCount'] = Post::all()->count();
        $data['categoriesCount'] = Category::all()->count();
        $data['tagsCount'] = Tag::all()->count();

        $getLocale = $this->getLocale();
        $getLocaleName = $this->getLocaleName();
        $locales = $this->getAllLocalizations();

//        $array = [$getLocale, $this->siteEntity->getConfigLocale()];
//        dd($array);

        return view('admin.main.index', compact('data', 'locales', 'getLocale', 'getLocaleName'));
    }
}

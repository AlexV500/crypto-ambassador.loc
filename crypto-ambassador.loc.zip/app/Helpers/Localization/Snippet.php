<?php

namespace App\Helpers\Localization;

use App\Http\Entities\Site;
use Illuminate\Support\Facades\DB;

class Snippet{

    public static function getSnippet($systemName) {

        $site = new Site();
        $snippet = DB::table('snippets')->where('system_name', $systemName)->where('lang', $site->getCurrentlocale())->first();

        return html_entity_decode($snippet->content);
    }
}

<?php

namespace App\View\Components\Admin;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class MenuBreadcrumbs extends Component
{
    public $html;
    private $menuBreadcrumbs;
    private $menuItem;

    /**
     * Create a new component instance.
     */
    public function __construct($menuBreadcrumbs, $menuItem)
    {
        $this->menuBreadcrumbs = $menuBreadcrumbs;
        $this->menuItem = $menuItem;
        $this->html = $this->prepareRender($menuBreadcrumbs);
    }

    public function prepareRender($menuItem){
        //   dd($menuItems);
        $html = $this->renderCrumbs($menuItem);
        $htmlEx = explode('@', $html);
        $htmlRev = array_reverse($htmlEx);
        $htmlImp = implode('', $htmlRev);
     //   dd($html);
        return $htmlImp;
    }

    private function renderCrumbs($renderCrumbs){

        $html = '';
        if(is_array($renderCrumbs) && (count($renderCrumbs) > 0)){
            $html .= '<li class="breadcrumb-item">'.$renderCrumbs[0]->label.'</li>@';
        } if(isset($renderCrumbs[1])){
            $html .= $this->renderCrumbs($renderCrumbs[1]);
        }
        return $html;
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        return view('components.admin.menu-breadcrumbs');
    }
}
